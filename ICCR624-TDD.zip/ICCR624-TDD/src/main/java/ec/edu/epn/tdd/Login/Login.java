package ec.edu.epn.tdd.Login;

public interface Login {

    public LoginResponse requestLogin(LoginRequest loginRequest);
}
