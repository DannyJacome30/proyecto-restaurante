package ec.du.epn.tdd.reserva;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Reservation {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/mm/dd");
   
    public int reser(Date fecha, String hora, int numPersonas) {
        String mesa="disponible";
        int rsv=0;
        if(mesa.equalsIgnoreCase("disponible"))
            rsv = 1;
        else if (mesa.equalsIgnoreCase("ocupado"))
            rsv = 0;
        return rsv;
    }

    public String confirmacionMesa(int mesa, int numPersonas) {
        return "ok";
    }

    public String verificarFecha(String date) throws ParseException {

        Date dateReservation = dateFormat.parse(date);
        Date dateActual = new Date();
        int dia = dateActual.getDate();
        int mes = dateActual.getMonth();
        int año = dateActual.getYear();

        String dateAct= dia + "/" + (mes+1) + "/" + año;
        Date dateToday = dateFormat.parse(dateAct);
        if (dateReservation.after(dateToday))
            return "ok";
        else
            return "error";

    }

}

